import React from 'react'

function App() {
  return (
    <div>Secure File Sharing</div>
  )
}

export default App